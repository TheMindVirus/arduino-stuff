#ifndef __MINILUA_C__
#define __MINILUA_C__

#include <Arduino.h>
#include "minilua.h"

static int lua_readline(void* L, int n, int o) { return 0; }
static void lua_freeline(void* L, int n) { }
static void lua_saveline(void* L, int n) { }
static int lua_stdin_is_tty() { return 1; }

#define strcoll(...) (0)
#define fopen(...) (0)
#define fseek(...) (0)
#define ftell(...) (0)
#define remove(...) (0)
#define setvbuf(...) (0)

typedef struct clock_t {};

char* setlocale(int category, const char* locale) { return ""; }
char* strerror(int errnum) { return ""; }
struct lconv* localeconv() { return 0; } //no struct memory, will override reset vector causing boot failure
struct clock_t clock() { struct clock_t c; return c; }
char* _CLOCKS_PER_SEC_ = "";

FILE* tmpfile() { }
char* tmpnam(char* s) { return ""; }
int rename(const char* oldpath, const char* newpath) { return 0; }

static int lua_wrapper_pinMode(lua_State* lua)
{
    int a = luaL_checkinteger(lua, 1);
    int b = luaL_checkinteger(lua, 2);
    pinMode(a, b);
}

static int lua_wrapper_digitalWrite(lua_State* lua)
{
    int a = luaL_checkinteger(lua, 1);
    int b = luaL_checkinteger(lua, 2);
    digitalWrite(a, b);
}
  
static int lua_wrapper_delay(lua_State* lua)
{
    int a = luaL_checkinteger(lua, 1);
    delay(a);
}

static int lua_wrapper_print(lua_State* lua)
{
    Serial_println(luaL_checkstring(lua, 1));
}

static int lua_wrapper_millis(lua_State* lua)
{
    lua_pushnumber(lua, (lua_Number) millis());
    return 1;
}

///lua.c///////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static lua_State* globalL = NULL;
static const char* progname = LUA_PROGNAME;

static void lstop (lua_State* L, lua_Debug* ar)
{
    (void)ar;
    lua_sethook(L, NULL, 0, 0);
    luaL_error(L, "interrupted!");
}

static void laction(int i)
{
    //signal(i, SIG_DFL);
    lua_sethook(globalL, lstop, LUA_MASKCALL | LUA_MASKRET | LUA_MASKCOUNT, 1);
}

static void print_usage(void)
{
    fprintf(stderr,
        "usage: %s [options] [script [args]].\n"
        "Available options are:\n"
        "  -e stat  execute string " LUA_QL("stat") "\n"
        "  -l name  require library " LUA_QL("name") "\n"
        "  -i       enter interactive mode after executing " LUA_QL("script") "\n"
        "  -v       show version information\n"
        "  --       stop handling options\n"
        "  -        execute stdin and stop handling options\n"
        , progname);
    fflush(stderr);
}

static void l_message(const char* pname, const char* msg)
{
    if (pname) fprintf(stderr, "%s: ", pname);
    fprintf(stderr, "%s\n", msg);
    fflush(stderr);
}

static int report(lua_State* L, int status)
{
    if (status && !lua_isnil(L, -1))
    {
        const char* msg = lua_tostring(L, -1);
        if (msg == NULL) { msg = "(error object is not a string)"; }
        l_message(progname, msg);
        lua_pop(L, 1);
    }
    return status;
}

static int traceback(lua_State* L)
{
    lua_getfield(L, LUA_GLOBALSINDEX, "debug");
    if (!lua_istable(L, -1)) { lua_pop(L, 1); return 1; }
    lua_getfield(L, -1, "traceback");
    if (!lua_isfunction(L, -1)) { lua_pop(L, 2); return 1; }
    lua_pushvalue(L, 1);
    lua_pushinteger(L, 2);
    lua_call(L, 2, 1);
    return 1;
}

static int docall(lua_State* L, int narg, int clear)
{
    int status;
    int base = lua_gettop(L) - narg;
    lua_pushcfunction(L, traceback);
    lua_insert(L, base);
    signal(SIGINT, laction);
    status = lua_pcall(L, narg, (clear ? 0 : LUA_MULTRET), base);
    //signal(SIGINT, SIG_DFL);
    lua_remove(L, base);
    if (status != 0) { lua_gc(L, LUA_GCCOLLECT, 0); }
    return status;
}

static void print_version (void) { l_message(NULL, LUA_VERSION "  " LUA_COPYRIGHT); }

static int getargs(lua_State* L, char** argv, int n)
{
    int narg;
    int argc = 0;
    while (argv[argc]) { ++argc; }
    narg = argc - (n + 1);
    luaL_checkstack(L, narg + 3, "too many arguments to script");
    for (int i = n + 1; i < argc; ++i) { lua_pushstring(L, argv[i]); }
    lua_createtable(L, narg, n + 1);
    for (int i = 0; i < argc; ++i)
    {
        lua_pushstring(L, argv[i]);
        lua_rawseti(L, -2, i - n);
    }
    return narg;
}

static int dofile(lua_State* L, const char* name)
{
    int status = luaL_loadfile(L, name) || docall(L, 0, 1);
    return report(L, status);
}

static int dostring(lua_State* L, const char* s, const char* name)
{
    int status = luaL_loadbuffer(L, s, strlen(s), name) || docall(L, 0, 1);
    return report(L, status);
}

static int dolibrary(lua_State* L, const char* name)
{
    lua_getglobal(L, "require");
    lua_pushstring(L, name);
    return report(L, lua_pcall(L, 1, 0, 0));
}

static const char* get_prompt(lua_State* L, int firstline)
{
    const char* p;
    lua_getfield(L, LUA_GLOBALSINDEX, firstline ? "_PROMPT" : "_PROMPT2");
    p = lua_tostring(L, -1);
    if (p == NULL) { p = (firstline ? LUA_PROMPT : LUA_PROMPT2); }
    lua_pop(L, 1);
    return p;
}

static int incomplete(lua_State* L, int status)
{
    if (status == LUA_ERRSYNTAX)
    {
        size_t lmsg;
        const char* msg = lua_tolstring(L, -1, &lmsg);
        const char* tp = msg + lmsg - (sizeof(LUA_QL("<eof>")) - 1);
        if (strstr(msg, LUA_QL("<eof>")) == tp)
        {
            lua_pop(L, 1);
            return 1;
        }
    }
    return 0;
}

static int pushline(lua_State* L, int firstline)
{
    char buffer[LUA_MAXINPUT];
    char* b = buffer;
    size_t l;
    const char* prmt = get_prompt(L, firstline);
    if (lua_readline(L, b, prmt) == 0) { return 0; }
    l = strlen(b);
    if (l > 0 && b[l-1] == '\n') { b[l-1] = '\0'; }
    if (firstline && b[0] == '=') { lua_pushfstring(L, "return %s", b + 1); }
    else { lua_pushstring(L, b); }
    lua_freeline(L, b);
    return 1;
}

static int loadline(lua_State* L)
{
    int status;
    lua_settop(L, 0);
    if (!pushline(L, 1)) { return -1; }
    for (;;)
    {
        status = luaL_loadbuffer(L, lua_tostring(L, 1), lua_strlen(L, 1), "=stdin");
        if (!incomplete(L, status)) { break; }
        if (!pushline(L, 0)) { return -1; }
        lua_pushliteral(L, "\n");
        lua_insert(L, -2);
        lua_concat(L, 3);
    }
    lua_saveline(L, 1);
    lua_remove(L, 1);
    return status;
}

static void dotty(lua_State* L)
{
    int status;
    const char *oldprogname = progname;
    progname = NULL;
    while ((status = loadline(L)) != -1)
    {
        if (status == 0) status = docall(L, 0, 0);
        report(L, status);
        if (status == 0 && lua_gettop(L) > 0)
        {
            lua_getglobal(L, "print");
            lua_insert(L, 1);
            if (lua_pcall(L, lua_gettop(L)-1, 0, 0) != 0) l_message(progname, 
                lua_pushfstring(L, "error calling " LUA_QL("print") " (%s)", lua_tostring(L, -1)));
        }
    }
    lua_settop(L, 0);
    fputs("\n", stdout);
    fflush(stdout);
    progname = oldprogname;
}

static int handle_script(lua_State* L, char** argv, int n)
{
    int status;
    const char* fname;
    int narg = getargs(L, argv, n);
    lua_setglobal(L, "arg");
    fname = argv[n];
    if (strcmp(fname, "-") == 0 && strcmp(argv[n - 1], "--") != 0) { fname = NULL; }
    status = luaL_loadfile(L, fname);
    lua_insert(L, -(narg + 1));
    if (status == 0) { status = docall(L, narg, 0); }
    else { lua_pop(L, narg); }
    return report(L, status);
}

static int collectargs(char**argv, int* pi, int* pv, int* pe)
{
    for (int i = 1; argv[i] != NULL; ++i)
    {
        if (argv[i][0] != '-') { return i; }
        switch (argv[i][1])
        {
            case '-': return (argv[i+1] != NULL ? i+1 : 0);
            case '\0': return i;
            case 'i': *pi = 1;
            case 'v': *pv = 1; break;
            case 'e': *pe = 1;
            case 'l':
            {
                if (argv[i][2] == '\0')
                {
                    ++i;
                    if (argv[i] == NULL) { return -1; }
                }
            }
            break;
            default: return -1;
        }
    }
    return 0;
}

static int runargs(lua_State* L, char** argv, int n)
{
    for (int i = 1; i < n; ++i)
    {
        if (argv[i] == NULL) { continue; }
        lua_assert(argv[i][0] == '-');
        switch (argv[i][1])
        {
            case 'e':
            {
                const char *chunk = argv[i] + 2;
                if (*chunk == '\0') chunk = argv[++i];
                lua_assert(chunk != NULL);
                if (dostring(L, chunk, "=(command line)") != 0) { return 1; }
                break;
            }
            case 'l':
            {
                const char *filename = argv[i] + 2;
                if (*filename == '\0') filename = argv[++i];
                lua_assert(filename != NULL);
                if (dolibrary(L, filename)) { return 1; }
                break;
            }
            default: break;
        }
    }
    return 0;
}

static int handle_luainit(lua_State* L)
{
    const char* init = getenv("LUA_INIT");
    if (init == NULL) { return 0; }
    else if (init[0] == '@') { return dofile(L, init+1); }
    else { return dostring(L, init, "=LUA_INIT"); }
}

struct Smain
{
    int argc;
    char** argv;
    int status;
};

static int pmain(lua_State* L)
{
    struct Smain* s = (struct Smain* )lua_touserdata(L, 1);
    char** argv = s->argv;
    int script;
    int has_i = 0, has_v = 0, has_e = 0;
    globalL = L;
    if (argv[0] && argv[0][0]) { progname = argv[0]; }
    lua_gc(L, LUA_GCSTOP, 0);
    luaL_openlibs(L);
    lua_gc(L, LUA_GCRESTART, 0);
    s->status = handle_luainit(L);
    if (s->status != 0) { return 0; }
    script = collectargs(argv, &has_i, &has_v, &has_e);
    if (script < 0)
    {
        print_usage();
        s->status = 1;
        return 0;
    }
    if (has_v) { print_version(); }
    s->status = runargs(L, argv, (script > 0) ? script : s->argc);
    if (s->status != 0) { return 0; }
    if (script) { s->status = handle_script(L, argv, script); }
    if (s->status != 0) { return 0; }
    if (has_i) { dotty(L); }
    else if (script == 0 && !has_e && !has_v)
    {
        print_version();
        dotty(L);
    }
    return 0;
}

///lauxlib.c///////////////////////////////////////////////

#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LUA_LIB
#define FREELIST_REF	0

#define abs_index(L, i)		((i) > 0 || (i) <= LUA_REGISTRYINDEX ? (i) : lua_gettop(L) + (i) + 1)

LUALIB_API int luaL_argerror(lua_State* L, int narg, const char* extramsg)
{
    lua_Debug ar;
    if (!lua_getstack(L, 0, &ar))
    {
        return luaL_error(L, "bad argument #%d (%s)", narg, extramsg);
    }
    lua_getinfo(L, "n", &ar);
    if (strcmp(ar.namewhat, "method") == 0)
    {
        --narg;
        if (narg == 0)
        {
            return luaL_error(L, "calling " LUA_QS " on bad self (%s)", ar.name, extramsg);
        }
    }
    if (ar.name == NULL) { ar.name = "?"; }
    return luaL_error(L, "bad argument #%d to " LUA_QS " (%s)", narg, ar.name, extramsg);
}

LUALIB_API int luaL_typerror(lua_State* L, int narg, const char* tname)
{
    const char* msg = lua_pushfstring(L, "%s expected, got %s", tname, luaL_typename(L, narg));
    return luaL_argerror(L, narg, msg);
}

static void tag_error(lua_State* L, int narg, int tag)
{
    luaL_typerror(L, narg, lua_typename(L, tag));
}

LUALIB_API void luaL_where(lua_State* L, int level)
{
    lua_Debug ar;
    if (lua_getstack(L, level, &ar))
    {
        lua_getinfo(L, "Sl", &ar);
        if (ar.currentline > 0)
        {
            lua_pushfstring(L, "%s:%d: ", ar.short_src, ar.currentline);
            return;
        }
    }
    lua_pushliteral(L, "");
}

LUALIB_API int luaL_error(lua_State* L, const char* fmt, ...)
{
    va_list argp;
    va_start(argp, fmt);
    luaL_where(L, 1);
    lua_pushvfstring(L, fmt, argp);
    va_end(argp);
    lua_concat(L, 2);
    return lua_error(L);
}

LUALIB_API int luaL_checkoption(lua_State* L, int narg, const char* def, const char* const lst[])
{
  const char* name = (def) ? luaL_optstring(L, narg, def) : luaL_checkstring(L, narg);
  for (int i = 0; lst[i]; ++i) { if (strcmp(lst[i], name) == 0) { return i; } }
  return luaL_argerror(L, narg, lua_pushfstring(L, "invalid option " LUA_QS, name));
}

LUALIB_API int luaL_newmetatable(lua_State* L, const char* tname)
{
    lua_getfield(L, LUA_REGISTRYINDEX, tname);
    if (!lua_isnil(L, -1)) { return 0; }
    lua_pop(L, 1);
    lua_newtable(L);
    lua_pushvalue(L, -1);
    lua_setfield(L, LUA_REGISTRYINDEX, tname);
    return 1;
}

LUALIB_API void* luaL_checkudata(lua_State* L, int ud, const char* tname)
{
    void* p = lua_touserdata(L, ud);
    lua_getfield(L, LUA_REGISTRYINDEX, tname);
    if (p == NULL || !lua_getmetatable(L, ud) || !lua_rawequal(L, -1, -2))
    { 
        luaL_typerror(L, ud, tname);
    }
    lua_pop(L, 2);
    return p;
}

LUALIB_API void luaL_checkstack(lua_State* L, int space, const char* mes)
{
    if (!lua_checkstack(L, space)) { luaL_error(L, "stack overflow (%s)", mes); }
}

LUALIB_API void luaL_checktype(lua_State* L, int narg, int t)
{
    if (lua_type(L, narg) != t) { tag_error(L, narg, t); }
}

LUALIB_API void luaL_checkany(lua_State* L, int narg)
{
    if (lua_type(L, narg) == LUA_TNONE) { luaL_argerror(L, narg, "value expected"); }
}

LUALIB_API const char* luaL_checklstring(lua_State* L, int narg, size_t* len)
{
    const char* s = lua_tolstring(L, narg, len);
    if (!s) { tag_error(L, narg, LUA_TSTRING); }
    return s;
}

LUALIB_API const char* luaL_optlstring(lua_State* L, int narg, const char* def, size_t* len)
{
    if (lua_isnoneornil(L, narg))
    {
        if (len) { *len = (def ? strlen(def) : 0); }
        return def;
    }
    else return luaL_checklstring(L, narg, len);
}

LUALIB_API lua_Number luaL_checknumber(lua_State* L, int narg)
{
    lua_Number d = lua_tonumber(L, narg);
    if (d == 0 && !lua_isnumber(L, narg)) { tag_error(L, narg, LUA_TNUMBER); }
    return d;
}

LUALIB_API lua_Number luaL_optnumber(lua_State* L, int narg, lua_Number def)
{
    return luaL_opt(L, luaL_checknumber, narg, def);
}

LUALIB_API lua_Integer luaL_checkinteger(lua_State* L, int narg)
{
    lua_Integer d = lua_tointeger(L, narg);
    if (d == 0 && !lua_isnumber(L, narg)) { tag_error(L, narg, LUA_TNUMBER); }
    return d;
}

LUALIB_API lua_Integer luaL_optinteger(lua_State* L, int narg, lua_Integer def)
{
    return luaL_opt(L, luaL_checkinteger, narg, def);
}

LUALIB_API int luaL_getmetafield(lua_State* L, int obj, const char* event)
{
    if (!lua_getmetatable(L, obj)) { return 0; }
    lua_pushstring(L, event);
    lua_rawget(L, -2);
    if (lua_isnil(L, -1))
    {
        lua_pop(L, 2);
        return 0;
    }
    else
    {
        lua_remove(L, -2);
        return 1;
    }
}

LUALIB_API int luaL_callmeta(lua_State* L, int obj, const char* event)
{
    obj = abs_index(L, obj);
    if (!luaL_getmetafield(L, obj, event)) { return 0; }
    lua_pushvalue(L, obj);
    lua_call(L, 1, 1);
    return 1;
}

LUALIB_API void luaL_register(lua_State* L, const char* libname, const luaL_Reg* l)
{
    luaI_openlib(L, libname, l, 0);
}

static int libsize(const luaL_Reg* l)
{
    int size = 0;
    for (; l->name; ++l) { ++size; }
    return size;
}

LUALIB_API void luaI_openlib(lua_State* L, const char* libname, const luaL_Reg* l, int nup)
{
    if (libname)
    {
        int size = libsize(l);
        luaL_findtable(L, LUA_REGISTRYINDEX, "_LOADED", size);
        lua_getfield(L, -1, libname);
        if (!lua_istable(L, -1))
        {
            lua_pop(L, 1);
            if (luaL_findtable(L, LUA_GLOBALSINDEX, libname, size) != NULL)
            {
                luaL_error(L, "name conflict for module " LUA_QS, libname);
            }
            lua_pushvalue(L, -1);
            lua_setfield(L, -3, libname);
        }
        lua_remove(L, -2);
        lua_insert(L, -(nup + 1));
    }
    for (; l->name; ++l)
    {
        for (int i = 0; i < nup; ++i) { lua_pushvalue(L, -nup); }
        lua_pushcclosure(L, l->func, nup);
        lua_setfield(L, -(nup+2), l->name);
    }
    lua_pop(L, nup);
}

#if defined(LUA_COMPAT_GETN)

static int checkint(lua_State* L, int topop)
{
    int n = (lua_type(L, -1) == LUA_TNUMBER) ? lua_tointeger(L, -1) : -1;
    lua_pop(L, topop);
    return n;
}

static void getsizes(lua_State* L)
{
    lua_getfield(L, LUA_REGISTRYINDEX, "LUA_SIZES");
    if (lua_isnil(L, -1))
    {
        lua_pop(L, 1);
        lua_newtable(L);
        lua_pushvalue(L, -1);
        lua_setmetatable(L, -2);
        lua_pushliteral(L, "kv");
        lua_setfield(L, -2, "__mode");
        lua_pushvalue(L, -1);
        lua_setfield(L, LUA_REGISTRYINDEX, "LUA_SIZES");
    }
}

LUALIB_API void luaL_setn(lua_State* L, int t, int n)
{
    t = abs_index(L, t);
    lua_pushliteral(L, "n");
    lua_rawget(L, t);
    if (checkint(L, 1) >= 0)
    {
        lua_pushliteral(L, "n");
        lua_pushinteger(L, n);
        lua_rawset(L, t);
    }
    else
    {
        getsizes(L);
        lua_pushvalue(L, t);
        lua_pushinteger(L, n);
        lua_rawset(L, -3);
        lua_pop(L, 1);
    }
}

LUALIB_API int luaL_getn(lua_State* L, int t)
{
    int n;
    t = abs_index(L, t);
    lua_pushliteral(L, "n");
    lua_rawget(L, t);
    if ((n = checkint(L, 1)) >= 0) { return n; }
    getsizes(L);
    lua_pushvalue(L, t);
    lua_rawget(L, -2);
    if ((n = checkint(L, 2)) >= 0) { return n; }
    return (int)lua_objlen(L, t);
}

#endif

LUALIB_API const char* luaL_gsub(lua_State* L, const char* s, const char* p, const char* r)
{
    const char* wild;
    size_t l = strlen(p);
    luaL_Buffer b;
    luaL_buffinit(L, &b);
    while ((wild = strstr(s, p)) != NULL)
    {
        luaL_addlstring(&b, s, wild - s);
        luaL_addstring(&b, r);
        s = wild + l;
    }
    luaL_addstring(&b, s);
    luaL_pushresult(&b);
    return lua_tostring(L, -1);
}

LUALIB_API const char* luaL_findtable(lua_State* L, int idx, const char* fname, int szhint)
{
    const char* e;
    lua_pushvalue(L, idx);
    do
    {
        e = strchr(fname, '.');
        if (e == NULL) e = fname + strlen(fname);
        lua_pushlstring(L, fname, e - fname);
        lua_rawget(L, -2);
        if (lua_isnil(L, -1))
        {
            lua_pop(L, 1);
            lua_createtable(L, 0, (*e == '.' ? 1 : szhint));
            lua_pushlstring(L, fname, e - fname);
            lua_pushvalue(L, -2);
            lua_settable(L, -4);
        }
        else if (!lua_istable(L, -1))
        {
            lua_pop(L, 2);
            return fname;
        }
        lua_remove(L, -2);
        fname = e + 1;
    }   while (*e == '.');
    return NULL;
}

#define bufflen(B)	((B)->p - (B)->buffer)
#define bufffree(B)	((size_t)(LUAL_BUFFERSIZE - bufflen(B)))

#define LIMIT	(LUA_MINSTACK/2)

static int emptybuffer(luaL_Buffer* B)
{
    size_t l = bufflen(B);
    if (l == 0) { return 0; }
    else
    {
        lua_pushlstring(B->L, B->buffer, l);
        B->p = B->buffer;
        B->lvl++;
        return 1;
    }
}

static void adjuststack(luaL_Buffer* B)
{
    if (B->lvl > 1)
    {
        lua_State* L = B->L;
        int toget = 1;
        size_t toplen = lua_strlen(L, -1);
        do
        {
            size_t l = lua_strlen(L, -(toget + 1));
            if (B->lvl - toget + 1 >= LIMIT || toplen > l)
            {
                toplen += l;
                ++toget;
            }
            else { break; }
        }   while (toget < B->lvl);
        lua_concat(L, toget);
        B->lvl = B->lvl - toget + 1;
    }
}

LUALIB_API char* luaL_prepbuffer(luaL_Buffer* B)
{
    if (emptybuffer(B)) { adjuststack(B); }
    return B->buffer;
}

LUALIB_API void luaL_addlstring(luaL_Buffer* B, const char* s, size_t l)
{
    while (l--) { luaL_addchar(B, *s++); }
}

LUALIB_API void luaL_addstring(luaL_Buffer* B, const char* s)
{
    luaL_addlstring(B, s, strlen(s));
}

LUALIB_API void luaL_pushresult(luaL_Buffer* B)
{
    emptybuffer(B);
    lua_concat(B->L, B->lvl);
    B->lvl = 1;
}

LUALIB_API void luaL_addvalue(luaL_Buffer* B)
{
    lua_State* L = B->L;
    size_t vl;
    const char* s = lua_tolstring(L, -1, &vl);
    if (vl <= bufffree(B))
    {
        memcpy(B->p, s, vl);
        B->p += vl;
        lua_pop(L, 1);
    }
    else
    {
        if (emptybuffer(B)) { lua_insert(L, -2); }
        B->lvl++;
        adjuststack(B);
    }
}

LUALIB_API void luaL_buffinit(lua_State* L, luaL_Buffer* B)
{
    B->L = L;
    B->p = B->buffer;
    B->lvl = 0;
}

LUALIB_API int luaL_ref(lua_State* L, int t)
{
    int ref;
    t = abs_index(L, t);
    if (lua_isnil(L, -1))
    {
        lua_pop(L, 1);
        return LUA_REFNIL;
    }
    lua_rawgeti(L, t, FREELIST_REF);
    ref = (int)lua_tointeger(L, -1);
    lua_pop(L, 1);
    if (ref != 0)
    {
        lua_rawgeti(L, t, ref);
        lua_rawseti(L, t, FREELIST_REF);
    }
    else
    {
        ref = (int)lua_objlen(L, t);
        ++ref;
    }
    lua_rawseti(L, t, ref);
    return ref;
}

LUALIB_API void luaL_unref(lua_State* L, int t, int ref)
{
    if (ref >= 0)
    {
        t = abs_index(L, t);
        lua_rawgeti(L, t, FREELIST_REF);
        lua_rawseti(L, t, ref);
        lua_pushinteger(L, ref);
        lua_rawseti(L, t, FREELIST_REF);
    }
}

typedef struct LoadF
{
    int extraline;
    FILE* f;
    char buff[LUAL_BUFFERSIZE];
}   LoadF;

static const char* getF(lua_State* L, void* ud, size_t* size)
{
    LoadF* lf = (LoadF*)ud;
    (void)L;
    if (lf->extraline)
    {
        lf->extraline = 0;
        *size = 1;
        return "\n";
    }
    if (feof(lf->f)) return NULL;
    *size = fread(lf->buff, 1, LUAL_BUFFERSIZE, lf->f);
    return (*size > 0) ? lf->buff : NULL;
}

static int errfile(lua_State* L, const char* what, int fnameindex)
{
    const char* serr = strerror(errno);
    const char* filename = lua_tostring(L, fnameindex) + 1;
    lua_pushfstring(L, "cannot %s %s: %s", what, filename, serr);
    lua_remove(L, fnameindex);
    return LUA_ERRFILE;
}

LUALIB_API int luaL_loadfile(lua_State* L, const char* filename)
{
    LoadF lf;
    int status, readstatus;
    int c;
    int fnameindex = lua_gettop(L) + 1;
    lf.extraline = 0;
    if (filename == NULL)
    {
        lua_pushliteral(L, "=stdin");
        lf.f = stdin;
    }
    else
    {
        lua_pushfstring(L, "@%s", filename);
        lf.f = fopen(filename, "r");
        if (lf.f == NULL) { return errfile(L, "open", fnameindex); }
    }
    c = getc(lf.f);
    if (c == '#') // Unix exec. file?
    {
        lf.extraline = 1;
        while (((c = getc(lf.f)) != EOF) && (c != '\n')); // skip first line
        if (c == '\n') { c = getc(lf.f); }
    }
    if (c == LUA_SIGNATURE[0] && lf.f != stdin) // binary file?
    {
        fclose(lf.f);
        lf.f = fopen(filename, "rb"); // reopen in binary mode
        if (lf.f == NULL) { return errfile(L, "reopen", fnameindex); }
        while (((c = getc(lf.f)) != EOF) && (c != LUA_SIGNATURE[0])); //skip this line
        lf.extraline = 0;
    }
    ungetc(c, lf.f);
    status = lua_load(L, getF, &lf, lua_tostring(L, -1));
    readstatus = ferror(lf.f);
    if (lf.f != stdin) { fclose(lf.f); }
    if (readstatus)
    {
        lua_settop(L, fnameindex);
        return errfile(L, "read", fnameindex);
    }
    lua_remove(L, fnameindex);
    return status;
}

typedef struct LoadS
{
    const char* s;
    size_t size;
}   LoadS;

static const char* getS(lua_State* L, void* ud, size_t* size)
{
    LoadS* ls = (LoadS*)ud;
    (void)L;
    if (ls->size == 0) { return NULL; }
    *size = ls->size;
    ls->size = 0;
    return ls->s;
}

LUALIB_API int luaL_loadbuffer(lua_State* L, const char* buff, size_t size, const char* name)
{
    LoadS ls;
    ls.s = buff;
    ls.size = size;
    return lua_load(L, getS, &ls, name);
}

LUALIB_API int luaL_loadstring(lua_State* L, const char* s)
{
    return luaL_loadbuffer(L, s, strlen(s), s);
}

static void* l_alloc(void* ud, void* ptr, size_t osize, size_t nsize)
{
    (void)ud;
    (void)osize;
    if (nsize == 0)
    {
        free(ptr);
        return NULL;
    }
    else { return realloc(ptr, nsize); }
}

static int panic(lua_State* L)
{
    (void)L;
    //fprintf(stderr, "PANIC: unprotected error in call to Lua API (%s)\n", lua_tostring(L, -1));
    Serial_println("%s", "[WARN]: API Error");
    return 0;
}

void HEX32(int value) //From PiX-iES
{
    Serial_printcc('I', 'N', 'F', 'O');
    Serial_printch('0');
    Serial_printch('x');
    byte map2[] = "0123456789ABCDEF";
    size_t ptr = 0;
    for (size_t i = 32; i > 0; i -= 4)
    {
        Serial_printch(map2[((value >> (i - 4)) & 0xF)]);
    }
    Serial_printch('\n');
}

//LUALIB_API lua_State* luaL_newstate(void)
lua_State* luaL_newstate(void)
{
    //lua_State* L = lua_newstate(l_alloc, NULL);
    //if (L) { lua_atpanic(L, &panic); }
    int L = 0xCDCDCDCD; //Pointer Error at this scope level
    //Serial_println("[BOOT]: 0x%08x", buffer); //C/C++ Cross Compatibility Error at this scope level
    HEX32(L); //Prints 0xFFFFCDCD on 8-bit micro
    return 1;
}

///lstate.c///////////////////////////////////////////////

LUA_API lua_State* lua_newstate(lua_Alloc f, void* ud)
{
    //Serial_println("[ADDR]: %s", ""); // 0x%08x", &LuaGlobalState); //Stack Corruption at this scope level
    return NULL;
}

///lapi.c///////////////////////////////////////////////

static TValue* index2adr(lua_State* L, int idx)
{
    if (idx > 0)
    {
        TValue* o = ((TValue*)(L)) + (idx - 1); //L->base + (idx - 1);
        api_check(L, idx <= L->ci->top - L->base);
        //if (o >= L->top) { return cast(TValue*, luaO_nilobject); } else { return o; }
    }
    else if (idx > LUA_REGISTRYINDEX)
    {
        api_check(L, idx != 0 && -idx <= L->top - L->base);
        return 0; //L->top + idx;
    }
    else switch (idx)
    {
        case LUA_REGISTRYINDEX: return registry(L);
        case LUA_ENVIRONINDEX:
        {
            Closure* func = curr_func(L);
            //sethvalue(L, &L->env, func->c.env);
            return 0; //&L->env;
        }
        case LUA_GLOBALSINDEX: return gt(L);
        default:
        {
            Closure* func = curr_func(L);
            idx = LUA_GLOBALSINDEX - idx;
            return (idx <= func->c.nupvalues) ? &func->c.upvalue[idx-1] : cast(TValue*, luaO_nilobject);
        }
    }
}

LUA_API const char* lua_tolstring(lua_State* L, int idx, size_t* len)
{
    StkId o = index2adr(L, idx);
    if (!ttisstring(o)) { o = index2adr(L, idx); }
    return o; //svalue(o);
}

LUA_API int lua_load(lua_State* L, lua_Reader reader, void* data, const char* chunkname)
{
    //ZIO z;
    int status;
    if (!chunkname) { chunkname = "?"; }
    //luaZ_init(L, &z, reader, data);
    //status = luaD_protectedparser(L, &z, chunkname);
    Serial_println(data);
    return status;
}

struct CallS
{
    StkId func;
    int nresults;
};

static void f_call(lua_State* L, void* ud)
{
    struct CallS* c = cast(struct CallS*, ud);
    luaD_call(L, c->func, c->nresults);
}

LUA_API int lua_pcall(lua_State* L, int nargs, int nresults, int errfunc)
{
    struct CallS c;
    int status;
    ptrdiff_t func;
    //api_checknelems(L, nargs + 1);
    //checkresults(L, nargs, nresults);
    if (errfunc == 0) { func = 0; }
    else
    {
        StkId o = index2adr(L, errfunc);
        api_checkvalidindex(L, o);
        func = savestack(L, o);
    }
    //c.func = (L->top) - (nargs + 1);
    c.nresults = nresults;
    //status = luaD_pcall(L, f_call, &c, savestack(L, c.func), func);
    status = luaD_pcall(L, f_call, &c, NULL, func);
    //adjustresults(L, nresults);
    return status;
}

///ldo.c///////////////////////////////////////////////

int luaD_precall(lua_State* L, StkId func, int nresults)
{
    //LClosure* cl;
    //ptrdiff_t funcr;
    //luaD_checkstack(L, LUA_MINSTACK);
    //int n = (*curr_func(L)->c.f)(L); // <-- do the actual call
    //if (n < 0) { return PCRYIELD; }
    //else
    //{
    //    luaD_poscall(L, L->top - n);
    //    return PCRC;
    //}
}

void luaD_call(lua_State* L, StkId func, int nResults)
{
    //if (++L->nCcalls >= LUAI_MAXCCALLS)
    //{
        //if (L->nCcalls == LUAI_MAXCCALLS) { Serial_println("[WARN]: Max Calls Reached"); }
        //else if (L->nCcalls >= (LUAI_MAXCCALLS + (LUAI_MAXCCALLS>>3))) { Serial_println("[WARN]: Max Calls Exceeded"); }
    //}
    //if (luaD_precall(L, func, nResults) == PCRLUA) { luaV_execute(L, 1); }
    //L->nCcalls--;
    //luaC_checkGC(L);
}

int luaD_poscall(lua_State* L, StkId firstResult)
{
    //StkId res;
    //int wanted; //uninitialised;
    //CallInfo *ci;
    //if (L->hookmask & LUA_MASKRET) { firstResult = callrethooks(L, firstResult); }
    //ci = L->ci--;
    //res = ci->func;
    //wanted = ci->nresults;
    //L->base = (ci - 1)->base;
    //L->savedpc = (ci - 1)->savedpc;
    //for (int i = wanted; i != 0 && firstResult < L->top; i--) { setobjs2s(L, res++, firstResult++); }
    //while (i-- > 0) { setnilvalue(res++); }
    //L->top = res;
    //return (wanted - LUA_MULTRET);
    return 0;
}

void luaD_pcall(lua_State* L, StkId func, int nResults)
{
    int status;
    unsigned short oldnCcalls = 0; // L->nCcalls;
    //ptrdiff_t old_ci = saveci(L, L->ci);
    uint8_t old_allowhooks = 0; //L->allowhook;
    ptrdiff_t old_errfunc = 0; //L->errfunc;
    //L->errfunc = ef;
    //status = luaD_rawrunprotected(L, func, u);
    if (status != 0)
    {
        //StkId oldtop = restorestack(L, old_top);
        //luaF_close(L, oldtop);
        //luaD_seterrorobj(L, status, oldtop);
        //L->nCcalls = oldnCcalls;
        //L->ci = restoreci(L, old_ci);
        //L->base = L->ci->base;
        //L->savedpc = L->ci->savedpc;
        //L->allowhook = old_allowhooks;
        restore_stack_limit(L);
    }
    //L->errfunc = old_errfunc;
    return status;
}

///lopcodes.c///////////////////////////////////////////////

///lparser.c///////////////////////////////////////////////


///lbaselib.c///////////////////////////////////////////////

///lcode.c///////////////////////////////////////////////

///ldblib.c///////////////////////////////////////////////

///ldebug.c///////////////////////////////////////////////

///ldump.c///////////////////////////////////////////////

///lfunc.c///////////////////////////////////////////////

///lgc.c///////////////////////////////////////////////

///linit.c///////////////////////////////////////////////

///liolib.c///////////////////////////////////////////////

///llex.c///////////////////////////////////////////////

///lmathlib.c///////////////////////////////////////////////

///lmem.c///////////////////////////////////////////////

///loadlib.c///////////////////////////////////////////////

///lobject.c///////////////////////////////////////////////

///loslib.c///////////////////////////////////////////////

///lstring.c///////////////////////////////////////////////

///lstrlib.c///////////////////////////////////////////////

///latable.c///////////////////////////////////////////////

///ltablib.c///////////////////////////////////////////////

///ltm.c///////////////////////////////////////////////

///lundump.c///////////////////////////////////////////////

///lvm.c///////////////////////////////////////////////

///lzio.c///////////////////////////////////////////////

#endif//__MINILUA_C__
