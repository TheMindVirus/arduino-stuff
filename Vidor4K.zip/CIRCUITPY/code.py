import board

print(dir(board))

"""
[
    '__name__', 'A0', 'A1', 'A2', 'A3', 'A4', 'A5', 'BATTERY',
    'D0', 'D1', 'D10', 'D11', 'D12', 'D13', 'D5', 'D6', 'D9',
    'I2C', 'LED', 'MISO', 'MOSI', 'RX', 'SCK', 'SCL', 'SDA', 'SPI',
    'TX', 'UART', 'VOLTAGE_MONITOR', 'board_id'
]
"""

"""
board_id = "feather_m0_basic"

VOLTAGE_MONITOR = PA07 #D9
BATTERY = PA07 #D9
LED = ???

UART = <function>
RX = PA11 #D0 (not PB23)
TX = PA10 #D1 (not PB22)

I2C = <function>
SDA = PA22
SCL = PA23

SPI = <function>
MOSI = PB10
MISO = PA12
SCK = PB11

A0 = PA02
A1 = PB08
A2 = PB09
A3 = PA04
A4 = PA05
A5 = PB02

D0 = PA11 #RX
D1 = PA10 #TX
(D2 = PA14)
(D3 = PA09)
(D4 = PA08)
D5 = PA15
D6 = PA20
(D7 = PA21)
D8 = PA06
D9 = PA07 #VOLTAGE_MONITOR #BATTERY
D10 = PA18
D11 = PA16
D12 = PA19
D13 = PA17
"""

"""
board_id = "mkr_4000_vidor"

(D2 = PA14) #JTAG_TMS (mode select not required?)
MISO = PA12 #JTAG_TDI
(??? = PA13) #JTAG_TCK (clock not available on feather?)
D5 = PA15 #JTAG_TDO

(D4 = PA08) #SDA (data line not available on feather?)
(D3 = PA09) #SCL (clock line not available on feather?)
"""

# Check a different SAMD21 board for more circuitpython support for the JTAG pins
# e.g. CircuitPlayground Express

"""
board_id = "circuitplayground_express"

D5_RIGHTBUTTON = PA14 #JTAG_TMS
D12_REMOTEIN = PA12 #JTAG_TDI
D36_LISIRQ = PA13 #JTAG_TCK
D7_SLIDESWITCH = PA15 #JTAG_TDO

I2S_DO = PA08 #SDA
A9_TEMP_SENSE = PA09 #SCL
"""

# I2C and SMBus are similar but not identical
# SPI and JTAG are similar but not identical