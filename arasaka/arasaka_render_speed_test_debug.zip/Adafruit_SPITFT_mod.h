#ifndef _ADAFRUIT_SPITFT_MOD_H_
#define _ADAFRUIT_SPITFT_MOD_H_

#include "SPI_mod.h"
#include "Adafruit_GFX_mod.h"

#ifndef ADAFRUIT_DEFAULT_SPI_SPEED
#define ADAFRUIT_DEFAULT_SPI_SPEED   64000000//1000000
#endif//ADAFRUIT_DEFAULT_SPI_SPEED

typedef uint8_t ADAGFX_PORT_t;       ///< PORT values are 8-bit
//typedef uint32_t ADAGFX_PORT_t; ///< PORT values are 32-bit
//typedef class HardwareSPI SPIClass;        ///< SPI is a bit odd on WICED
//typedef class SPI SPIClass;
typedef volatile ADAGFX_PORT_t* PORTreg_t; ///< PORT register type

enum tftBusWidth { tft8bitbus, tft16bitbus };

class Adafruit_SPITFT_mod : public Adafruit_GFX_mod
{
public:
    Adafruit_SPITFT_mod(uint16_t w, uint16_t h, int8_t cs, int8_t dc, int8_t mosi,
                        int8_t sck, int8_t rst = -1, int8_t miso = -1);
    Adafruit_SPITFT_mod(uint16_t w, uint16_t h, int8_t cs, int8_t dc, int8_t rst = -1);
    Adafruit_SPITFT_mod(uint16_t w, uint16_t h, tftBusWidth busWidth, int8_t d0,
                        int8_t wr, int8_t dc, int8_t cs = -1, int8_t rst = -1, int8_t rd = -1);
    Adafruit_SPITFT_mod(uint16_t w, uint16_t h, SPIClass* spiClass, int8_t cs,
                        int8_t dc, int8_t rst = -1);
    ~Adafruit_SPITFT_mod(){};

    virtual void begin(uint32_t freq) = 0;
    virtual void setAddrWindow(uint16_t x, uint16_t y, uint16_t w, uint16_t h) = 0;

    void initSPI(uint32_t freq = 0, uint8_t spiMode = SPI_MODE0);
    void setSPISpeed(uint32_t freq);
    void startWrite(void);
    void endWrite(void);
    void sendCommand(uint8_t commandByte, uint8_t* dataBytes, uint8_t numDataBytes);
    void sendCommand(uint8_t commandByte, const uint8_t* dataBytes = NULL, uint8_t numDataBytes = 0);
    void sendCommand16(uint16_t commandWord, const uint8_t* dataBytes = NULL, uint8_t numDataBytes = 0);
    uint8_t readcommand8(uint8_t commandByte, uint8_t index = 0);
    uint16_t readcommand16(uint16_t addr);

    void writePixel(int16_t x, int16_t y, uint16_t color);
    void writePixels(uint16_t* colors, uint32_t len, bool block = true, bool bigEndian = false);
    void writeColor(uint16_t color, uint32_t len);
    void writeFillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
    void writeFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color);
    void writeFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color);
    inline void writeFillRectPreclipped(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
    void dmaWait(void);
    bool dmaBusy(void) const; // true if DMA is used and busy, false otherwise
    void swapBytes(uint16_t* src, uint32_t len, uint16_t* dest = NULL);

    void drawPixel(int16_t x, int16_t y, uint16_t color);
    void fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
    void drawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color);
    void drawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color);
    void pushColor(uint16_t color);

    using Adafruit_GFX_mod::drawRGBBitmap; // Check base class first
    void drawRGBBitmap(int16_t x, int16_t y, uint16_t* pcolors, int16_t w, int16_t h);

    void invertDisplay(bool i);
    uint16_t color565(uint8_t r, uint8_t g, uint8_t b);

    void spiWrite(uint8_t b);          // Write single byte as DATA
    void writeCommand(uint8_t cmd);    // Write single byte as COMMAND
    uint8_t spiRead(void);             // Read single byte of data
    void write16(uint16_t w);          // Write 16-bit value as DATA
    void writeCommand16(uint16_t cmd); // Write 16-bit value as COMMAND
    uint16_t read16(void);             // Read single 16-bit value

    void SPI_WRITE16(uint16_t w); // Not inline
    void SPI_WRITE32(uint32_t l); // Not inline

    void SPI_CS_HIGH(void) { digitalWrite(_cs, HIGH); }
    void SPI_CS_LOW(void) { digitalWrite(_cs, LOW); }
    void SPI_DC_HIGH(void) { digitalWrite(_dc, HIGH); }
    void SPI_DC_LOW(void) { digitalWrite(_dc, LOW); }

protected:
    inline void SPI_MOSI_HIGH(void);
    inline void SPI_MOSI_LOW(void);
    inline void SPI_SCK_HIGH(void);
    inline void SPI_SCK_LOW(void);
    inline bool SPI_MISO_READ(void);
    inline void SPI_BEGIN_TRANSACTION(void);
    inline void SPI_END_TRANSACTION(void);

    PORTreg_t csPortSet; ///< PORT register for chip select SET
    PORTreg_t csPortClr; ///< PORT register for chip select CLEAR
    PORTreg_t dcPortSet; ///< PORT register for data/command SET
    PORTreg_t dcPortClr; ///< PORT register for data/command CLEAR
    PORTreg_t csPort;                 ///< PORT register for chip select
    PORTreg_t dcPort;                 ///< PORT register for data/command

    struct
    {
        SPIClass* _spi; ///< SPI class pointer
        SPISettings settings; ///< SPI transaction settings
        uint32_t _freq; ///< SPI bitrate (if no SPI transactions)
        uint32_t _mode; ///< SPI data mode (transactions or no)
    }   hwspi;

    struct
    {
        PORTreg_t misoPort; ///< PORT (PIN) register for MISO

        PORTreg_t mosiPortSet; ///< PORT register for MOSI SET
        PORTreg_t mosiPortClr; ///< PORT register for MOSI CLEAR
        PORTreg_t sckPortSet;  ///< PORT register for SCK SET
        PORTreg_t sckPortClr;  ///< PORT register for SCK CLEAR

        ADAGFX_PORT_t mosiPinMask; ///< Bitmask for MOSI
        ADAGFX_PORT_t sckPinMask;  ///< Bitmask for SCK

        PORTreg_t mosiPort;           ///< PORT register for MOSI
        PORTreg_t sckPort;            ///< PORT register for SCK
        ADAGFX_PORT_t mosiPinMaskSet; ///< Bitmask for MOSI SET (OR)
        ADAGFX_PORT_t mosiPinMaskClr; ///< Bitmask for MOSI CLEAR (AND)
        ADAGFX_PORT_t sckPinMaskSet;  ///< Bitmask for SCK SET (OR bitmask)
        ADAGFX_PORT_t sckPinMaskClr;  ///< Bitmask for SCK CLEAR (AND)

        ADAGFX_PORT_t misoPinMask; ///< Bitmask for MISO

        int8_t _mosi;              ///< MOSI pin #
        int8_t _miso;              ///< MISO pin #
        int8_t _sck;               ///< SCK pin #
    }   swspi;

    ADAGFX_PORT_t csPinMask; ///< Bitmask for chip select
    ADAGFX_PORT_t dcPinMask; ///< Bitmask for data/command

    ADAGFX_PORT_t csPinMaskSet;     ///< Bitmask for chip select SET (OR)
    ADAGFX_PORT_t csPinMaskClr;     ///< Bitmask for chip select CLEAR (AND)
    ADAGFX_PORT_t dcPinMaskSet;     ///< Bitmask for data/command SET (OR)
    ADAGFX_PORT_t dcPinMaskClr;     ///< Bitmask for data/command CLEAR (AND)

    uint8_t connection;      ///< TFT_HARD_SPI, TFT_SOFT_SPI, etc.
    int8_t _rst;             ///< Reset pin # (or -1)
    int8_t _cs;              ///< Chip select pin # (or -1)
    int8_t _dc;              ///< Data/command pin #

    int16_t _xstart = 0;          ///< Internal framebuffer X offset
    int16_t _ystart = 0;          ///< Internal framebuffer Y offset
    uint8_t invertOnCommand = 0;  ///< Command to enable invert mode
    uint8_t invertOffCommand = 0; ///< Command to disable invert mode

    uint32_t _freq = 0; ///< Dummy var to keep subclasses happy
};

#endif//_ADAFRUIT_SPITFT_MOD_H_
