#include "Adafruit_SPITFT_mod.h"

#define TFT_HARD_SPI 0
#define TFT_SOFT_SPI 1

Adafruit_SPITFT_mod::Adafruit_SPITFT_mod(uint16_t w, uint16_t h, int8_t cs, int8_t dc,
                                         int8_t mosi, int8_t sck, int8_t rst, int8_t miso)
    : Adafruit_GFX_mod(w, h), connection(TFT_SOFT_SPI), _rst(rst), _cs(cs), _dc(dc)
{
    swspi._sck = sck;
    swspi._mosi = mosi;
    swspi._miso = miso;

    dcPinMask = digitalPinToBitMask(dc);
    swspi.sckPinMask = digitalPinToBitMask(sck);
    swspi.mosiPinMask = digitalPinToBitMask(mosi);
    //dcPortSet = &(PORT->Group[g_APinDescription[dc].ulPort].OUTSET.reg);
    //dcPortClr = &(PORT->Group[g_APinDescription[dc].ulPort].OUTCLR.reg);
    //swspi.sckPortSet = &(PORT->Group[g_APinDescription[sck].ulPort].OUTSET.reg);
    //swspi.sckPortClr = &(PORT->Group[g_APinDescription[sck].ulPort].OUTCLR.reg);
    //swspi.mosiPortSet = &(PORT->Group[g_APinDescription[mosi].ulPort].OUTSET.reg);
    //swspi.mosiPortClr = &(PORT->Group[g_APinDescription[mosi].ulPort].OUTCLR.reg);
    if (cs >= 0)
    {
        csPinMask = digitalPinToBitMask(cs);
        //csPortSet = &(PORT->Group[g_APinDescription[cs].ulPort].OUTSET.reg);
        //csPortClr = &(PORT->Group[g_APinDescription[cs].ulPort].OUTCLR.reg);
    }
    else
    {
        csPortSet = dcPortSet;
        csPortClr = dcPortClr;
        csPinMask = 0;
    }
    if (miso >= 0)
    {
        swspi.misoPinMask = digitalPinToBitMask(miso);
        swspi.misoPort = (PORTreg_t)portInputRegister(digitalPinToPort(miso));
    }
    else
    {
        swspi.misoPinMask = 0;
        swspi.misoPort = (PORTreg_t)portInputRegister(digitalPinToPort(dc));
    }

    dcPort = (PORTreg_t)portOutputRegister(digitalPinToPort(dc));
    dcPinMaskSet = digitalPinToBitMask(dc);
    swspi.sckPort = (PORTreg_t)portOutputRegister(digitalPinToPort(sck));
    swspi.sckPinMaskSet = digitalPinToBitMask(sck);
    swspi.mosiPort = (PORTreg_t)portOutputRegister(digitalPinToPort(mosi));
    swspi.mosiPinMaskSet = digitalPinToBitMask(mosi);
    if (cs >= 0)
    {
        csPort = (PORTreg_t)portOutputRegister(digitalPinToPort(cs));
        csPinMaskSet = digitalPinToBitMask(cs);
    }
    else
    {
        csPort = dcPort;
        csPinMaskSet = 0;
    }
    if (miso >= 0)
    {
        swspi.misoPort = (PORTreg_t)portInputRegister(digitalPinToPort(miso));
        swspi.misoPinMask = digitalPinToBitMask(miso);
    }
    else
    {
        swspi.misoPort = (PORTreg_t)portInputRegister(digitalPinToPort(dc));
        swspi.misoPinMask = 0;
    }
    csPinMaskClr = ~csPinMaskSet;
    dcPinMaskClr = ~dcPinMaskSet;
    swspi.sckPinMaskClr = ~swspi.sckPinMaskSet;
    swspi.mosiPinMaskClr = ~swspi.mosiPinMaskSet;
}

Adafruit_SPITFT_mod::Adafruit_SPITFT_mod(uint16_t w, uint16_t h, int8_t cs, int8_t dc, int8_t rst)
    : Adafruit_SPITFT_mod(w, h, &SPI, cs, dc, rst) { }

Adafruit_SPITFT_mod::Adafruit_SPITFT_mod(uint16_t w, uint16_t h, SPIClass* spiClass,
                                         int8_t cs, int8_t dc, int8_t rst)
    : Adafruit_GFX_mod(w, h), connection(TFT_HARD_SPI), _rst(rst), _cs(cs), _dc(dc)
{
    hwspi._spi = spiClass;

    dcPinMask = digitalPinToBitMask(dc);
    //dcPortSet = &(PORT->Group[g_APinDescription[dc].ulPort].OUTSET.reg);
    //dcPortClr = &(PORT->Group[g_APinDescription[dc].ulPort].OUTCLR.reg);
    if (cs >= 0)
    {
        csPinMask = digitalPinToBitMask(cs);
        //csPortSet = &(PORT->Group[g_APinDescription[cs].ulPort].OUTSET.reg);
        //csPortClr = &(PORT->Group[g_APinDescription[cs].ulPort].OUTCLR.reg);
    }
    else
    {
        csPortSet = dcPortSet;
        csPortClr = dcPortClr;
        csPinMask = 0;
    }

    dcPort = (PORTreg_t)portOutputRegister(digitalPinToPort(dc));
    dcPinMaskSet = digitalPinToBitMask(dc);
    if (cs >= 0)
    {
        csPort = (PORTreg_t)portOutputRegister(digitalPinToPort(cs));
        csPinMaskSet = digitalPinToBitMask(cs);
    }
    else
    {
        csPort = dcPort;
        csPinMaskSet = 0;
    }
    csPinMaskClr = ~csPinMaskSet;
    dcPinMaskClr = ~dcPinMaskSet;
}

void Adafruit_SPITFT_mod::initSPI(uint32_t freq, uint8_t spiMode)
{
    if (!freq) { freq = ADAFRUIT_DEFAULT_SPI_SPEED; } // If no freq specified, use default //From Adafruit_SPIDevice_mod.h in BUSIO 

    // Init basic control pins common to all connection types
    if (_cs >= 0)
    {
        pinMode(_cs, OUTPUT);
        digitalWrite(_cs, HIGH); // Deselect
    }
    pinMode(_dc, OUTPUT);
    digitalWrite(_dc, HIGH); // Data mode

    if (connection == TFT_HARD_SPI) //Not Currently Using Hardware SPI
    {
        #if defined(SPI_HAS_TRANSACTION)
           hwspi.settings = SPISettings(freq, MSBFIRST, spiMode);
        #else
           hwspi._freq = freq; // Save freq value for later
        #endif
        hwspi._mode = spiMode; // Save spiMode value for later
        hwspi._spi->begin();
    }
    else if (connection == TFT_SOFT_SPI) //Currently Using Software SPI
    {
        pinMode(swspi._mosi, OUTPUT);
        digitalWrite(swspi._mosi, LOW);
        pinMode(swspi._sck, OUTPUT);
        digitalWrite(swspi._sck, LOW);
        if (swspi._miso >= 0) { pinMode(swspi._miso, INPUT); }
        //SPI.begin(); //Hardware SPI
    }

    if (_rst >= 0)
    {
        pinMode(_rst, OUTPUT);
        digitalWrite(_rst, HIGH);
        delay(100);
        digitalWrite(_rst, LOW);
        delay(100);
        digitalWrite(_rst, HIGH);
        delay(200);
    }
}

void Adafruit_SPITFT_mod::setSPISpeed(uint32_t freq)
{
    #if defined(SPI_HAS_TRANSACTION)
        hwspi.settings = SPISettings(freq, MSBFIRST, hwspi._mode);
    #else
        hwspi._freq = freq; // Save freq value for later
    #endif
}

void Adafruit_SPITFT_mod::startWrite(void)
{
    SPI_BEGIN_TRANSACTION();
    if (_cs >= 0) { SPI_CS_LOW(); }
}

void Adafruit_SPITFT_mod::endWrite(void)
{
    if (_cs >= 0) { SPI_CS_HIGH(); }
    SPI_END_TRANSACTION();
}

void Adafruit_SPITFT_mod::writePixel(int16_t x, int16_t y, uint16_t color) //This one for drawBitmap
{
    if ((x >= 0) && (x < _width) && (y >= 0) && (y < _height))
    {
        //setAddrWindow(x, y, 1, 1);
        SPI_WRITE16(color);
    }
}

void Adafruit_SPITFT_mod::swapBytes(uint16_t* src, uint32_t len, uint16_t* dest)
{
    if (!dest) { dest = src; } // NULL -> overwrite src buffer
    for (uint32_t i = 0; i < len; ++i) { dest[i] = __builtin_bswap16(src[i]); }
}

void Adafruit_SPITFT_mod::writePixels(uint16_t *colors, uint32_t len, bool block, bool bigEndian)
{
    if (!len) { return; } // Avoid 0-byte transfers
    (void)block;
    (void)bigEndian;

    if (!bigEndian) { while (len--) { SPI_WRITE16(*colors++); } }
    else { while (len--) { SPI_WRITE16(__builtin_bswap16(*colors++)); } }
}

void Adafruit_SPITFT_mod::dmaWait(void) {}
bool Adafruit_SPITFT_mod::dmaBusy(void) const { return false; }
void Adafruit_SPITFT_mod::writeColor(uint16_t color, uint32_t len)
{
    if (!len) { return; } // Avoid 0-byte transfers
    uint8_t hi = color >> 8, lo = color;

    if (connection == TFT_HARD_SPI)
    {
        while (len--)
        {
            //AVR_WRITESPI(hi);
            //AVR_WRITESPI(lo);
            hwspi._spi->transfer(hi);
            hwspi._spi->transfer(lo);
        }
    }
    else if (connection == TFT_SOFT_SPI)
    {
        while (len--)
        {
            for (uint8_t bit = 0, x = hi; bit < 8; ++bit)
            {
                if (x & 0x80) { SPI_MOSI_HIGH(); }
                else { SPI_MOSI_LOW(); }
                SPI_SCK_HIGH();
                SPI_SCK_LOW();
                x <<= 1;
            }
            for (uint8_t bit = 0, x = lo; bit < 8; ++bit)
            {
                if (x & 0x80) { SPI_MOSI_HIGH(); }
                else { SPI_MOSI_LOW(); }
                SPI_SCK_HIGH();
                SPI_SCK_LOW();
                x <<= 1;
            }
        }
    }
}

void Adafruit_SPITFT_mod::writeFillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color)
{
    if (w && h)
    {   // Nonzero width and height?
        if (w < 0)
        {  // If negative width...
            x += w + 1; //   Move X to left edge
            w = -w;     //   Use positive width
        }
        if (x < _width)
        { // Not off right
            if (h < 0)
            {    // If negative height...
                y += h + 1;   //   Move Y to top edge
                h = -h;       //   Use positive height
            }
            if (y < _height)
            { // Not off bottom
                int16_t x2 = x + w - 1;
                if (x2 >= 0)
                { // Not off left
                    int16_t y2 = y + h - 1;
                    if (y2 >= 0)
                    { // Not off top
                        // Rectangle partly or fully overlaps screen
                        if (x < 0)
                        {
                            x = 0;
                            w = x2 + 1;
                        } // Clip left
                        if (y < 0)
                        {
                            y = 0;
                            h = y2 + 1;
                        } // Clip top
                        if (x2 >= _width)
                        {
                            w = _width - x;
                        } // Clip right
                        if (y2 >= _height)
                        {
                            h = _height - y;
                        } // Clip bottom
                        writeFillRectPreclipped(x, y, w, h, color);
                    }
                }
            }
        }
    }
}

void inline Adafruit_SPITFT_mod::writeFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color)
{
    if ((y >= 0) && (y < _height) && w)
    { // Y on screen, nonzero width
        if (w < 0)
        {                        // If negative width...
            x += w + 1;                       //   Move X to left edge
            w = -w;                           //   Use positive width
        }
        if (x < _width)
        { // Not off right
            int16_t x2 = x + w - 1;
            if (x2 >= 0)
            { // Not off left
                // Line partly or fully overlaps screen
                if (x < 0)
                {
                    x = 0;
                    w = x2 + 1;
                } // Clip left
                if (x2 >= _width)
                {
                    w = _width - x;
                } // Clip right
                writeFillRectPreclipped(x, y, w, 1, color);
            }
        }
    }
}

void inline Adafruit_SPITFT_mod::writeFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color)
{
    if ((x >= 0) && (x < _width) && h)
    { // X on screen, nonzero height
        if (h < 0)
        {                       // If negative height...
            y += h + 1;                      //   Move Y to top edge
            h = -h;                          //   Use positive height
        }
        if (y < _height)
        { // Not off bottom
            int16_t y2 = y + h - 1;
            if (y2 >= 0)
            { // Not off top
                // Line partly or fully overlaps screen
                if (y < 0)
                {
                    y = 0;
                    h = y2 + 1;
                } // Clip top
                if (y2 >= _height)
                {
                    h = _height - y;
                } // Clip bottom
                writeFillRectPreclipped(x, y, 1, h, color);
            }
        }
    }
}

inline void Adafruit_SPITFT_mod::writeFillRectPreclipped(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color)
{
    setAddrWindow(x, y, w, h);
    writeColor(color, (uint32_t)w * h);
}

void Adafruit_SPITFT_mod::drawPixel(int16_t x, int16_t y, uint16_t color)
{
    if ((x >= 0) && (x < _width) && (y >= 0) && (y < _height))
    {
        startWrite();
        setAddrWindow(x, y, 1, 1);
        SPI_WRITE16(color);
        endWrite();
    }
}

void Adafruit_SPITFT_mod::fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color)
{
    if (w && h)
    {   // Nonzero width and height?
        if (w < 0)
        {  // If negative width...
            x += w + 1; //   Move X to left edge
            w = -w;     //   Use positive width
        }
        if (x < _width)
        { // Not off right
            if (h < 0)
            {    // If negative height...
                y += h + 1;   //   Move Y to top edge
                h = -h;       //   Use positive height
            }
            if (y < _height)
            { // Not off bottom
                int16_t x2 = x + w - 1;
                if (x2 >= 0)
                { // Not off left
                    int16_t y2 = y + h - 1;
                    if (y2 >= 0)
                    { // Not off top
                         // Rectangle partly or fully overlaps screen
                        if (x < 0)
                        {
                            x = 0;
                            w = x2 + 1;
                        } // Clip left
                        if (y < 0)
                        {
                            y = 0;
                            h = y2 + 1;
                        } // Clip top
                        if (x2 >= _width)
                        {
                            w = _width - x;
                        } // Clip right
                        if (y2 >= _height)
                        {
                            h = _height - y;
                        } // Clip bottom
                        startWrite();
                        writeFillRectPreclipped(x, y, w, h, color);
                        endWrite();
                    }
                }
            }
        }
    }
}

void Adafruit_SPITFT_mod::drawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color)
{
    if ((y >= 0) && (y < _height) && w)
    { // Y on screen, nonzero width
        if (w < 0)
        {                        // If negative width...
            x += w + 1;                       //   Move X to left edge
            w = -w;                           //   Use positive width
        }
        if (x < _width)
        { // Not off right
            int16_t x2 = x + w - 1;
            if (x2 >= 0)
            { // Not off left
                 // Line partly or fully overlaps screen
                if (x < 0)
                {
                    x = 0;
                    w = x2 + 1;
                } // Clip left
                if (x2 >= _width)
                {
                    w = _width - x;
                } // Clip right
                startWrite();
                writeFillRectPreclipped(x, y, w, 1, color);
                endWrite();
            }
        }
    }
}

void Adafruit_SPITFT_mod::drawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color)
{
    if ((x >= 0) && (x < _width) && h)
    { // X on screen, nonzero height
        if (h < 0)
        {                       // If negative height...
            y += h + 1;                      //   Move Y to top edge
            h = -h;                          //   Use positive height
        }
        if (y < _height)
        { // Not off bottom
            int16_t y2 = y + h - 1;
            if (y2 >= 0)
            { // Not off top
                // Line partly or fully overlaps screen
                if (y < 0)
                {
                    y = 0;
                    h = y2 + 1;
                } // Clip top
                if (y2 >= _height)
                {
                    h = _height - y;
                } // Clip bottom
                startWrite();
                writeFillRectPreclipped(x, y, 1, h, color);
                endWrite();
            }
        }
    }
}

void Adafruit_SPITFT_mod::pushColor(uint16_t color)
{
    startWrite();
    SPI_WRITE16(color);
    endWrite();
}

void Adafruit_SPITFT_mod::drawRGBBitmap(int16_t x, int16_t y, uint16_t* pcolors, int16_t w, int16_t h)
{
    int16_t x2, y2;                 // Lower-right coord
    if ((x >= _width) ||            // Off-edge right
        (y >= _height) ||           // " top
        ((x2 = (x + w - 1)) < 0) || // " left
        ((y2 = (y + h - 1)) < 0))
        { return; } // " bottom

    int16_t bx1 = 0, by1 = 0, // Clipped top-left within bitmap
        saveW = w;            // Save original bitmap width value
    if (x < 0)
    {              // Clip left
        w += x;
        bx1 = -x;
        x = 0;
    }
    if (y < 0)
    { // Clip top
        h += y;
        by1 = -y;
        y = 0;
    }
    if (x2 >= _width) { w = _width - x; } // Clip right
    if (y2 >= _height) { h = _height - y; } // Clip bottom

    pcolors += by1 * saveW + bx1; // Offset bitmap ptr to clipped top-left
    startWrite();
    setAddrWindow(x, y, w, h); // Clipped area
    while (h--)
    {              // For each (clipped) scanline...
        writePixels(pcolors, w); // Push one (clipped) row
        pcolors += saveW;        // Advance pointer by one full (unclipped) line
    }
    endWrite();
}

void Adafruit_SPITFT_mod::invertDisplay(bool i)
{
    startWrite();
    writeCommand(i ? invertOnCommand : invertOffCommand);
    endWrite();
}

uint16_t Adafruit_SPITFT_mod::color565(uint8_t red, uint8_t green, uint8_t blue)
{
    return ((red & 0xF8) << 8) | ((green & 0xFC) << 3) | (blue >> 3);
}

void Adafruit_SPITFT_mod::sendCommand(uint8_t commandByte, uint8_t* dataBytes, uint8_t numDataBytes)
{
    SPI_BEGIN_TRANSACTION();
    if (_cs >= 0) { SPI_CS_LOW(); }

    SPI_DC_LOW();          // Command mode
    spiWrite(commandByte); // Send the command byte

    SPI_DC_HIGH();
    for (int i = 0; i < numDataBytes; ++i)
    {
        spiWrite(*dataBytes); // Send the data bytes
        ++dataBytes;
    }
    if (_cs >= 0) { SPI_CS_HIGH(); }
    SPI_END_TRANSACTION();
}

void Adafruit_SPITFT_mod::sendCommand(uint8_t commandByte, const uint8_t* dataBytes, uint8_t numDataBytes)
{
    SPI_BEGIN_TRANSACTION();
    if (_cs >= 0) { SPI_CS_LOW(); }
    SPI_DC_LOW();          // Command mode
    spiWrite(commandByte); // Send the command byte

    SPI_DC_HIGH();
    for (int i = 0; i < numDataBytes; ++i)
    {
        spiWrite(pgm_read_byte(dataBytes++));
    }
    if (_cs >= 0) { SPI_CS_HIGH(); }
    SPI_END_TRANSACTION();
}

void Adafruit_SPITFT_mod::sendCommand16(uint16_t commandWord, const uint8_t* dataBytes, uint8_t numDataBytes)
{
    SPI_BEGIN_TRANSACTION();
    if (_cs >= 0) { SPI_CS_LOW(); }
    if (numDataBytes == 0)
    {
        SPI_DC_LOW();             // Command mode
        SPI_WRITE16(commandWord); // Send the command word
        SPI_DC_HIGH();            // Data mode
    }
    for (int i = 0; i < numDataBytes; ++i)
    {
        SPI_DC_LOW();             // Command mode
        SPI_WRITE16(commandWord); // Send the command word
        SPI_DC_HIGH();            // Data mode
        ++commandWord;
        SPI_WRITE16((uint16_t)pgm_read_byte(dataBytes++));
    }
    if (_cs >= 0) { SPI_CS_HIGH(); }
    SPI_END_TRANSACTION();
}

uint8_t Adafruit_SPITFT_mod::readcommand8(uint8_t commandByte, uint8_t index)
{
    uint8_t result;
    startWrite();
    SPI_DC_LOW(); // Command mode
    spiWrite(commandByte);
    SPI_DC_HIGH(); // Data mode
    do { result = spiRead(); } while (index--); // Discard bytes up to index'th
    endWrite();
    return result;
}

uint16_t Adafruit_SPITFT_mod::readcommand16(uint16_t addr)
{
    (void)addr;
    return 0;
}

inline void Adafruit_SPITFT_mod::SPI_BEGIN_TRANSACTION(void)
{
    if (connection == TFT_HARD_SPI)
    {
        #if defined(SPI_HAS_TRANSACTION)
            hwspi._spi->beginTransaction(hwspi.settings);
        #else // No transactions, configure SPI manually...
            hwspi._spi->setClockDivider(SPI_CLOCK_DIV2);
            hwspi._spi->setBitOrder(MSBFIRST);
            hwspi._spi->setDataMode(hwspi._mode);
        #endif // end !SPI_HAS_TRANSACTION
    }
    //if (connection == TFT_SOFT_SPI) { SPI.beginTransaction(hwspi.settings); } //NEW
    //if (connection == TFT_SOFT_SPI) { SPI.beginTransaction(SPISettings(14000000, MSBFIRST, SPI_MODE0)); } //NEW
}

inline void Adafruit_SPITFT_mod::SPI_END_TRANSACTION(void)
{
    #if defined(SPI_HAS_TRANSACTION)
        if (connection == TFT_HARD_SPI) { hwspi._spi->endTransaction(); }
    #endif
    //if (connection == TFT_SOFT_SPI) { SPI.endTransaction(); } //NEW
}

void Adafruit_SPITFT_mod::spiWrite(uint8_t b)
{
    if (connection == TFT_HARD_SPI)
    {
        hwspi._spi->transfer(b);
    }
    else if (connection == TFT_SOFT_SPI)
    {
        //SPI.transfer(b); //Doesn't Work, uses hardwired SPI pins
        /*
        for (uint8_t bit = 0; bit < 8; ++bit)
        {
            if (b & 0x80) { SPI_MOSI_HIGH(); }
            else { SPI_MOSI_LOW(); }
            SPI_SCK_HIGH();
            b <<= 1;
            SPI_SCK_LOW();
        }
        */
        /*
        (b & 0x80) ? SPI_MOSI_HIGH() : SPI_MOSI_LOW();
        SPI_SCK_HIGH(); SPI_SCK_LOW();
        (b & 0x40) ? SPI_MOSI_HIGH() : SPI_MOSI_LOW();
        SPI_SCK_HIGH(); SPI_SCK_LOW();
        (b & 0x20) ? SPI_MOSI_HIGH() : SPI_MOSI_LOW();
        SPI_SCK_HIGH(); SPI_SCK_LOW();
        (b & 0x10) ? SPI_MOSI_HIGH() : SPI_MOSI_LOW();
        SPI_SCK_HIGH(); SPI_SCK_LOW();
        (b & 0x08) ? SPI_MOSI_HIGH() : SPI_MOSI_LOW();
        SPI_SCK_HIGH(); SPI_SCK_LOW();
        (b & 0x04) ? SPI_MOSI_HIGH() : SPI_MOSI_LOW();
        SPI_SCK_HIGH(); SPI_SCK_LOW();
        (b & 0x02) ? SPI_MOSI_HIGH() : SPI_MOSI_LOW();
        SPI_SCK_HIGH(); SPI_SCK_LOW();
        (b & 0x01) ? SPI_MOSI_HIGH() : SPI_MOSI_LOW();
        SPI_SCK_HIGH(); SPI_SCK_LOW();
        */
        /*
        digitalWrite(swspi._mosi, (b & 0x80));
        digitalWrite(swspi._sck, HIGH); digitalWrite(swspi._sck, LOW);
        digitalWrite(swspi._mosi, (b & 0x40));
        digitalWrite(swspi._sck, HIGH); digitalWrite(swspi._sck, LOW);
        digitalWrite(swspi._mosi, (b & 0x20));
        digitalWrite(swspi._sck, HIGH); digitalWrite(swspi._sck, LOW);
        digitalWrite(swspi._mosi, (b & 0x10));
        digitalWrite(swspi._sck, HIGH); digitalWrite(swspi._sck, LOW);
        digitalWrite(swspi._mosi, (b & 0x08));
        digitalWrite(swspi._sck, HIGH); digitalWrite(swspi._sck, LOW);
        digitalWrite(swspi._mosi, (b & 0x04));
        digitalWrite(swspi._sck, HIGH); digitalWrite(swspi._sck, LOW);
        digitalWrite(swspi._mosi, (b & 0x02));
        digitalWrite(swspi._sck, HIGH); digitalWrite(swspi._sck, LOW);
        digitalWrite(swspi._mosi, (b & 0x01));
        digitalWrite(swspi._sck, HIGH); digitalWrite(swspi._sck, LOW);
        */
        ///*
        (b & 0b10000000) ? (PORTD |= 0b00001000) : (PORTD &= 0b11110111);
        PORTD |= 0b00000100; PORTD &= 0b11111011;
        (b & 0b01000000) ? (PORTD |= 0b00001000) : (PORTD &= 0b11110111);
        PORTD |= 0b00000100; PORTD &= 0b11111011;
        (b & 0b00100000) ? (PORTD |= 0b00001000) : (PORTD &= 0b11110111);
        PORTD |= 0b00000100; PORTD &= 0b11111011;
        (b & 0b00010000) ? (PORTD |= 0b00001000) : (PORTD &= 0b11110111);
        PORTD |= 0b00000100; PORTD &= 0b11111011;
        (b & 0b00001000) ? (PORTD |= 0b00001000) : (PORTD &= 0b11110111);
        PORTD |= 0b00000100; PORTD &= 0b11111011;
        (b & 0b00000100) ? (PORTD |= 0b00001000) : (PORTD &= 0b11110111);
        PORTD |= 0b00000100; PORTD &= 0b11111011;
        (b & 0b00000010) ? (PORTD |= 0b00001000) : (PORTD &= 0b11110111);
        PORTD |= 0b00000100; PORTD &= 0b11111011;
        (b & 0b00000001) ? (PORTD |= 0b00001000) : (PORTD &= 0b11110111);
        PORTD |= 0b00000100; PORTD &= 0b11111011;
        //*/
    }
}

void Adafruit_SPITFT_mod::writeCommand(uint8_t cmd)
{
    SPI_DC_LOW();
    spiWrite(cmd);
    SPI_DC_HIGH();
}

uint8_t Adafruit_SPITFT_mod::spiRead(void)
{
    uint8_t b = 0;
    uint16_t w = 0;
    if (connection == TFT_HARD_SPI) { return hwspi._spi->transfer((uint8_t)0); }
    else if (connection == TFT_SOFT_SPI)
    {
        if (swspi._miso >= 0)
        {
            for (uint8_t i = 0; i < 8; ++i)
            {
                SPI_SCK_HIGH();
                b <<= 1;
                if (SPI_MISO_READ()) { ++b; }
                SPI_SCK_LOW();
            }
        }
        return b;
    }
    return w;
}

void Adafruit_SPITFT_mod::write16(uint16_t w) {}

void Adafruit_SPITFT_mod::writeCommand16(uint16_t cmd)
{
    SPI_DC_LOW();
    write16(cmd);
    SPI_DC_HIGH();
}

uint16_t Adafruit_SPITFT_mod::read16(void) { return 0; }

inline void Adafruit_SPITFT_mod::SPI_MOSI_HIGH(void) { digitalWrite(swspi._mosi, HIGH); }
inline void Adafruit_SPITFT_mod::SPI_MOSI_LOW(void) { digitalWrite(swspi._mosi, LOW); }
inline void Adafruit_SPITFT_mod::SPI_SCK_HIGH(void) { digitalWrite(swspi._sck, HIGH); }
inline void Adafruit_SPITFT_mod::SPI_SCK_LOW(void) { digitalWrite(swspi._sck, LOW); }
inline bool Adafruit_SPITFT_mod::SPI_MISO_READ(void) { return digitalRead(swspi._miso); }

void Adafruit_SPITFT_mod::SPI_WRITE16(uint16_t w) //This one for drawBitmap
{
    if (connection == TFT_HARD_SPI)
    {
        hwspi._spi->transfer(w >> 8);
        hwspi._spi->transfer(w);
    }
    else if (connection == TFT_SOFT_SPI)
    {
        for (uint8_t bit = 0; bit < 16; ++bit)
        {
            if (w & 0x8000) { SPI_MOSI_HIGH(); }
            else { SPI_MOSI_LOW(); }
            SPI_SCK_HIGH();
            SPI_SCK_LOW();
            w <<= 1;
        }
    }
}

void Adafruit_SPITFT_mod::SPI_WRITE32(uint32_t l)
{
    if (connection == TFT_HARD_SPI)
    {
        hwspi._spi->transfer(l >> 24);
        hwspi._spi->transfer(l >> 16);
        hwspi._spi->transfer(l >> 8);
        hwspi._spi->transfer(l);
    }
    else if (connection == TFT_SOFT_SPI)
    {
        for (uint8_t bit = 0; bit < 32; ++bit)
        {
            if (l & 0x80000000) { SPI_MOSI_HIGH(); }
            else { SPI_MOSI_LOW(); }
            SPI_SCK_HIGH();
            SPI_SCK_LOW();
            l <<= 1;
        }
    }
}
