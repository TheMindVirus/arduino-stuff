#ifndef __ARDUINO_LUA_H__
#define __ARDUINO_LUA_H__

#include "Arduino.h"

extern "C"
{
    int lua_readline(void* L, int n, int o); //{ return 0; }
    void lua_freeline(void* L, int n); //{ }
    void lua_saveline(void* L, int n); //{ }
    bool lua_stdin_is_tty(); //{ return true; }

    #define strcoll(...) 0
    #define fopen(...) 0
    #define fseek(...) 0
    #define ftell(...) 0
    #define remove(...) 0
    #define setvbuf(...) 0
    //#define setlocale(...)
    //#define os_setlocale(...) 0
  
    #include "lua/lua.h"
    #include "lua/luaconf.h"
    
    #ifndef HUGE_VAL
    #define HUGE_VAL (__builtin_huge_val())
    #endif

    #define LUA_MAXINPUT 255
    #define LUA_PROGNAME "ArduinoLua"
    #define LUA_PROMPT ">"
    #define LUA_PROMPT2 ">>"
    
    #define LUA_TMPNAMBUFSIZE 255 //L_tmpnam
    #define lua_tmpnam(b, e) { e = (tmpnam(b) == NULL); }

    #define signal(...)
  
    #include "lua/lapi.h"
    #include "lua/lauxlib.h"
    #include "lua/lcode.h"
    #include "lua/ldebug.h"
    #include "lua/ldo.h"
    #include "lua/lfunc.h"
    #include "lua/lgc.h"
    #include "lua/llex.h"
    #include "lua/llimits.h"
    #include "lua/lmem.h"
    #include "lua/lobject.h"
    #include "lua/lparser.h"
    #include "lua/lstate.h"
    #include "lua/lstring.h"
    #include "lua/ltable.h"
    //#include "lua/ltests.h"
    #include "lua/ltm.h"
    #include "lua/lualib.h"
    #include "lua/lundump.h"
    #include "lua/lvm.h"
    #include "lua/lzio.h"
}

class ArduinoLua
{
public:
  ArduinoLua();
  String evaluate(const String* script);
  void method(const String name, const lua_CFunction function);

private:
  lua_State* _state;
  String addConstants();
};

#endif//__ARDUINO_LUA_H__
