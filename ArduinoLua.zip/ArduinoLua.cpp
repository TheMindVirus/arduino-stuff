#include "ArduinoLua.h"

#ifndef __ARDUINO_LUA_C__
#define __ARDUINO_LUA_C__

extern "C"
{
    #define throw(...)
    #define try
    #define catch(...)

    #include "lua/lapi.c"
    #include "lua/lauxlib.c"
    #include "lua/lbaselib.c"
    #include "lua/lcode.c"
    #include "lua/ldblib.c"
    #include "lua/ldebug.c"
    #include "lua/ldo.c"
    #include "lua/ldump.c"
    #include "lua/lfunc.c"
    #include "lua/lgc.c"
    #include "lua/linit.c"
    #include "lua/liolib.c"
    #include "lua/llex.c"
    #include "lua/lmathlib.c"
    #include "lua/lmem.c"
    #include "lua/loadlib.c"
    #include "lua/lobject.c"
    #include "lua/lopcodes.c"
    #include "lua/loslib.c"
    #include "lua/lparser.c"
    #include "lua/lstate.c"
    #include "lua/lstring.c"
    #include "lua/lstrlib.c"
    #include "lua/ltable.c"
    #include "lua/ltablib.c"
    //#include "lua/ltests.c"
    #include "lua/ltm.c"
    #include "lua/lua.c"
    #include "lua/lundump.c"
    #include "lua/lvm.c"
    #include "lua/lzio.c"

    int lua_readline(void* L, int n, int o) { return 0; }
    void lua_freeline(void* L, int n) { }
    void lua_saveline(void* L, int n) { }
    bool lua_stdin_is_tty() { return false; }

    char* setlocale(int category, const char* locale) { return ""; }
    char* strerror(int errnum) { return ""; }
    struct lconv* localeconv() { return 0; } //no struct memory, will override reset vector causing boot failure
    clock_t clock() { return clock_t(); }
    char* _CLOCKS_PER_SEC_ = "";
    
    FILE* tmpfile() { }
    char* tmpnam(char* s) { return ""; }
    int rename(const char* oldpath, const char* newpath) { return 0; }
}

#endif//__ARDUINO_LUA_C__

extern "C"
{
  static int lua_wrapper_pinMode(lua_State* lua)
  {
    int a = luaL_checkinteger(lua, 1);
    int b = luaL_checkinteger(lua, 2);
    pinMode(a, b);
  }

  static int lua_wrapper_digitalWrite(lua_State* lua)
  {
    int a = luaL_checkinteger(lua, 1);
    int b = luaL_checkinteger(lua, 2);
    digitalWrite(a, b);
  }
  
  static int lua_wrapper_delay(lua_State* lua)
  {
    int a = luaL_checkinteger(lua, 1);
    delay(a);
  }

  static int lua_wrapper_print(lua_State* lua)
  {
    String a = String(luaL_checkstring(lua, 1));
    Serial.println(a);
  }

  static int lua_wrapper_millis(lua_State* lua)
  {
    lua_pushnumber(lua, (lua_Number) millis());
    return 1;
  }
}

ArduinoLua::ArduinoLua()
{
  _state = luaL_newstate();
  lua_register(_state, "pinMode", lua_wrapper_pinMode);
  lua_register(_state, "digitalWrite", lua_wrapper_digitalWrite);
  lua_register(_state, "delay", lua_wrapper_delay);
  lua_register(_state, "print", lua_wrapper_print);
  lua_register(_state, "millis", lua_wrapper_millis);
}

String ArduinoLua::evaluate(const String* script)
{
  String scriptWithConstants = addConstants() + *script;
  String result;
  if (luaL_dostring(_state, scriptWithConstants.c_str()))
  {
    result += "# lua error:\n" + String(lua_tostring(_state, -1));
    lua_pop(_state, 1);
  }
  return result;
}

void ArduinoLua::method(const String name, const lua_CFunction function)
{
  lua_register(_state, name.c_str(), function);
}

String ArduinoLua::addConstants()
{
  String constants = "INPUT = " + String(INPUT) + "\r\n";
  constants += "OUTPUT = " + String(OUTPUT) + "\r\n";
  constants += "LOW = " + String(LOW) + "\r\n";
  constants += "HIGH = " + String(HIGH) + "\r\n";
  return constants;
}
