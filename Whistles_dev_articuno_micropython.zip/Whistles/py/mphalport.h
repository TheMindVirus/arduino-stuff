// Define so there's no dependency on extmod/virtpin.h
#define mp_hal_pin_obj_t
