/*
  Client.h - Base class that provides Client
  Copyright (c) 2011 Adrian McEwen.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef client_h
#define client_h
#include "Print.h"
#include "Stream.h"
#include "IPAddress.h"

int stream_connect(struct IPAddress ip, uint16_t port);
int stream_connect(const char *host, uint16_t port);
size_t stream_write(uint8_t);
size_t stream_write(const uint8_t *buf, size_t size);
int stream_available();
int stream_read();
int stream_read(uint8_t *buf, size_t size);
int stream_peek();
void stream_flush();
void stream_stop();
uint8_t stream_connected();
uint8_t* rawIPAddress(struct IPAddress& addr) { return addr.raw_address(); };

#endif
